const { BasePage } = require('../../../pages/base_page.js');
const { LogFileRequestPage } = require('../../../pages/service_logFile_page.js');
const { TestData } = require('../../../utils/test_data.js');
const { TokenGenerators } = require('../../../utils/token_generators.js')
const { test, expect } = require('@playwright/test');
const { CustomerListPage } = require('../../../pages/customer_list_page.js');
const { CustomerDetailsPage } = require('../../../pages/customer_details_page.js');

var basePage, customerListPage, customerDetailsPage, servicePage, token;
var activationKey, conn,activationStatus, customerDetailsId, groupId,deviceId, customerId, sastoken, customerDetailsRecordSet, customer ;

const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
var hypervDeviceId = process.env.regularUserHypervDeviceId;


test.describe("Timeframe Updates in WebUI", function () {

  test.beforeAll(async function () {
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId ='" + hypervDeviceId + "' and activationStatus='True' for json auto")
    var devicesRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    deviceId = devicesRecord[0].iotDeviceId;
    customerDetailsId = devicesRecord[0].customerDetailsId;
    groupId = devicesRecord[0].groupId;
    conn = await TestData.sqlDBConnection();
    customerDetailsRecordSet = await TestData.executeSqlQuery(conn, "select * from [dbo].[CustomerDetails] where customerdetailsId=" + customerDetailsId + " for json auto")
    var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    customerId = customerDetailsRecord[0].customerId;
    customer = customerDetailsRecord[0].customerName;
    console.log("customerId: " + customer)
    console.log("deviceId: " + deviceId)
    token = await TokenGenerators.generateAuthToken("regularuser");
    sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)
  });

  test.beforeEach(async function ({ page }) {
    basePage = new BasePage(page);
    customerListPage = new CustomerListPage(page);
    customerDetailsPage = new CustomerDetailsPage(page);
    servicePage = new LogFileRequestPage(page);
  })

  //US#177337
  test('In WebUI, Regular user should be able to view the timeframes for updates @177337', async function () {
    await basePage.navigateToUrl("regularuser");
    // await homePage.clickSettings(); commenting out as settings button is descoped till integration with HDP
    await customerDetailsPage.selectCMInstance(deviceId);
    await customerDetailsPage.selectCMInstanceSettings(deviceId);
    expect(await customerDetailsPage.getSelectedTimeframeOption()).toEqual(groupId.toString())
    var time1 = await (await customerDetailsPage.getTimeframeRadioButton(1)).getAttribute("label");
    var time2 = await (await customerDetailsPage.getTimeframeRadioButton(2)).getAttribute("label");
    var time3 = await (await customerDetailsPage.getTimeframeRadioButton(3)).getAttribute("label");

    var time1Boundaries = time1.split("-")
    var time2Boundaries = time2.split("-")
    var time3Boundaries = time3.split("-")
    expect((await TestData.getUTCTimeCustom(time1Boundaries[0])).includes("02:00:00")).toEqual(true)
    expect((await TestData.getUTCTimeCustom(time1Boundaries[1])).includes("04:00:00")).toEqual(true)
    console.log(await TestData.getUTCTimeCustom(time2Boundaries[0]))
    console.log(await TestData.getUTCTimeCustom(time2Boundaries[1]))
    expect((await TestData.getUTCTimeCustom(time2Boundaries[0])).includes("10:00:00")).toEqual(true)
    expect((await TestData.getUTCTimeCustom(time2Boundaries[1])).includes("12:00:00")).toEqual(true)
    expect((await TestData.getUTCTimeCustom(time3Boundaries[0])).includes("04:00:00")).toEqual(true)
    expect((await TestData.getUTCTimeCustom(time3Boundaries[1])).includes("06:00:00")).toEqual(true)
  });

  //US#177339
  test('In WebUI, Regular user should be able to change the timeframe for updates @177339', async function () {
    await basePage.navigateToUrl("regularuser");
    await customerDetailsPage.selectCMInstance(deviceId);
    await customerDetailsPage.selectCMInstanceSettings(deviceId);
    expect(await customerDetailsPage.getSelectedTimeframeOption()).toEqual(groupId.toString())
    var updatedGroupId
    if (groupId == 1) {
      updatedGroupId = 2;
    } else if (groupId == 2) {
      updatedGroupId = 3;
    } else if (groupId == 3) {
      updatedGroupId = 1;
    }
    await customerDetailsPage.selectTimeframe(updatedGroupId);
    expect(await customerDetailsPage.getSelectedTimeframeOption()).toEqual(updatedGroupId.toString())
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotDeviceId='" + deviceId + "' for json auto");
    var devicesRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    expect(devicesRecord[0].groupId).toEqual(updatedGroupId);

  });
});
