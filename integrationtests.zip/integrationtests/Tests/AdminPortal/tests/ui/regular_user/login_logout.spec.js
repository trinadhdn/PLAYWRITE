const { BasePage } = require('../../../pages/base_page.js');
const { HomePage } = require('../../../pages/home_page.js');
const { test, expect } = require('@playwright/test');
var OR = require('../../../resources/OR.json');
var basePage, homePage;

test.describe('Login and logout', function(){

    test.beforeEach(async function ({ page }) {
		basePage = new BasePage(page);
		homePage= new HomePage(page);
	})

    //US#98430
	test('Regular user should be able to successfully login and logout of the Connectivity Module Web UI @98430', async function(){    
		await basePage.navigateToUrl("regularuser");
		expect(await basePage.verifyloggedInUsername("regularuser")).toEqual(true);
		// await homePage.clickSettings(); commenting out as settings button is descoped till integration with HDP
		await basePage.logout();
		var un= await homePage.usernameInput()
		var status= await un.isVisible()
		expect(status).toBe(true);
		
	});
	
});
