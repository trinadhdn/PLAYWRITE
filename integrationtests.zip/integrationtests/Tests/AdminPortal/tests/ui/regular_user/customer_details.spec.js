const{ BasePage } = require('../../../pages/base_page.js');
const { CustomerDetailsPage } = require('../../../pages/customer_details_page.js');
const { TestData } = require('../../../utils/test_data.js');
const { test, expect } = require('@playwright/test');
var basePage, customerDetailsPage,customerDetailsId,customerDetailsRecordSet, customerId,conn;

test.describe('Customer Details', function(){

    test.beforeEach(async function({page}){
        basePage = new BasePage(page);
        customerDetailsPage = new CustomerDetailsPage(page);
    })

	
	// US#98430 US#124751
	test('Regular user should NOT have access to the service and device sub menus in customer details page @98430 @124751', async function(){
		var conn = await TestData.sqlDBConnection();
		var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId='5985') and activationStatus='True' for json auto")
		var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
		var deviceId = deviceRecord[0].iotDeviceId;
		await basePage.navigateToUrl("regularuser");		
		
		expect(await customerDetailsPage.isCustomerButtonTextPresent()).toEqual(false);
		await customerDetailsPage.selectCMInstance(deviceId);
        expect(await customerDetailsPage.isCMInstanceDevicesPresent(deviceId)).toEqual(false);
		expect(await customerDetailsPage.isCMInstanceServicePresent(deviceId)).toEqual(false);
		expect(await customerDetailsPage.isDevicesTablePresent()).toEqual(false);

	});


	//US#124751
	test('Regular user should NOT have access to Other customer IDs @124751', async function () {
		var conn = await TestData.sqlDBConnection();
		var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId!='5985') and activationStatus='True' for json auto")
		var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
		var deviceId = deviceRecord[0].iotDeviceId;
		customerDetailsId = deviceRecord[0].customerDetailsId ;
		conn = await TestData.sqlDBConnection();
		customerDetailsRecordSet = await TestData.executeSqlQuery(conn,"select * from [dbo].[CustomerDetails] where customerdetailsId="+customerDetailsId+" for json auto")
		var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
		customerId = customerDetailsRecord[0].customerId;
		await basePage.navigateToUrl("regularuser");
		var url = process.env.adminAppBaseURL+ "customer/"+customerId;
		await basePage.navigateToCustomUrl(url);
        var hfg=await customerDetailsPage.isCMInstancePresent(deviceId)
		expect(hfg).toEqual(false);
		
	});


	
	//US#124751
	test('Regular user should NOT have access to devices module @124751', async function () {
		var conn = await TestData.sqlDBConnection();
		var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId!='5985') and activationStatus='True' for json auto")
		var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
		var deviceId = deviceRecord[0].iotDeviceId;
		customerDetailsId = deviceRecord[0].customerDetailsId ;
		conn = await TestData.sqlDBConnection();
		customerDetailsRecordSet = await TestData.executeSqlQuery(conn,"select * from [dbo].[CustomerDetails] where customerdetailsId="+customerDetailsId+" for json auto")
		var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
		customerId = customerDetailsRecord[0].customerId;
		await basePage.navigateToUrl("regularuser");
		var url = `${process.env.adminAppBaseURL}customer/${customerId}/connectivitymodule/${deviceId}/devices`;
		await basePage.navigateToCustomUrl(url);
		expect(await customerDetailsPage.isCMInstancePresent(deviceId)).toEqual(false);
		expect(await customerDetailsPage.isCMInstanceDevicesPresent(deviceId)).toEqual(false);
		expect(await customerDetailsPage.isCMInstanceServicePresent(deviceId)).toEqual(false);
		
	});

		//US#124751
		test('Regular user should NOT have access to services Module @124751', async function () {
			var conn = await TestData.sqlDBConnection();
			var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId='5985') and activationStatus='True' for json auto")
			var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
			var deviceId = deviceRecord[0].iotDeviceId;
			customerDetailsId = deviceRecord[0].customerDetailsId ;
			conn = await TestData.sqlDBConnection();
			customerDetailsRecordSet = await TestData.executeSqlQuery(conn,"select * from [dbo].[CustomerDetails] where customerdetailsId="+customerDetailsId+" for json auto")
			var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
			customerId = customerDetailsRecord[0].customerId;
			await basePage.navigateToUrl("regularuser");
			var url = `${process.env.adminAppBaseURL}customer/${customerId}/connectivitymodule/${deviceId}/services`;
			await basePage.navigateToCustomUrl(url);
			expect(await customerDetailsPage.isCMInstancePresent(deviceId)).toEqual(false);
			expect(await customerDetailsPage.isCMInstanceDevicesPresent(deviceId)).toEqual(false);
			expect(await customerDetailsPage.isCMInstanceServicePresent(deviceId)).toEqual(false);
			
		});
	
});
