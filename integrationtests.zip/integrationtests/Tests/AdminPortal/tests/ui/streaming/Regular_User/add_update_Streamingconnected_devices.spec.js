const { BasePage } = require('../../../../pages/base_page.js');
const { TokenGenerators } = require('../../../../utils/token_generators.js')
const { test, expect } = require('@playwright/test');
const { IotHubMethods } = require('../../../../utils/iothub_methods.js');
const { Comparisions } = require('../../../../utils/comparisions.js');
const { CustomerListPage } = require('../../../../pages/customer_list_page.js');
const { CustomerDetailsPage } = require('../../../../pages/customer_details_page.js');
const { TestData } = require('../../../../utils/test_data.js');
const { ApiHelper } = require('../../../../helpers/api-helpers.js')
var OR = require('../../../../resources/OR.json');

const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
var deviceId, customer,customerDetailsId,customerDetailsRecordSet, conn, token, customerId, universalLocation, universallocIDfromResp;
var hypervDeviceId = process.env.regularUserHypervDeviceId;
var testDevice = process.env.serviceUserHypervDeviceId;
var basePage, customerListPage, customerDetailsPage, sastoken;
test.describe('Streaming connected devices Management', function () {
    test.beforeAll(async function () {

        // test data preparation     
        sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)

        conn = await TestData.sqlDBConnection();
        var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId = '" + hypervDeviceId + "' for json auto")
        var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        customerDetailsId = deviceRecord[0].customerDetailsId;
        conn = await TestData.sqlDBConnection();
        customerDetailsRecordSet = await TestData.executeSqlQuery(conn, "select * from [dbo].[CustomerDetails] where customerdetailsId=" + customerDetailsId + " for json auto")
        var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        customerId = customerDetailsRecord[0].customerId;
        customer = customerDetailsRecord[0].customerName;
        console.log("customerId: " + customer)
        console.log("deviceId: " + deviceId)

    });

    test.beforeEach(async function ({ page }) {
        basePage = new BasePage(page);
        customerListPage = new CustomerListPage(page);
        customerDetailsPage = new CustomerDetailsPage(page);
        token = await TokenGenerators.generateAuthToken("l1serviceuser");
        await ApiHelper.deleteAll_ActiveDevice(token, deviceId);
        await ApiHelper.deleteAll_InActiveDevice(token, deviceId);
        await ApiHelper.deleteAll_AutomationDeviceLocations(token, customerId);
        universalLocation = "AutoLoc-rstm" + await ApiHelper.createlocname(4);
        var locDesc = "This is the location: " + universalLocation;
        var status = "active";
        var postresponse = await ApiHelper.postlocationList(token, customerId, universalLocation, locDesc, status)
        expect(postresponse.status).toBe(200);
        universallocIDfromResp = postresponse.data.result.id;
    })
    //US#310324
    test('Regular user should be able to add a new streaming device successfully with all the parameters  @310324', async function () {
        let areEqual = new Array(), expectedJSON, iothubJSON;
        await basePage.navigateToUrl("regularuser");
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        await customerDetailsPage.addDeviceButtonClick();
        await customerDetailsPage.selectAddDeviceType("STREAMING");

        await expect(await customerDetailsPage.isAEIDFieldSVisible()).toEqual(false);
        await expect(await customerDetailsPage.isPORTFieldVisible()).toEqual(false);
        await expect(await customerDetailsPage.isModalityFieldVisible()).toEqual(false);

        let localSerialNumber = await TestData.generateSerialNumber();
        let localAet = await TestData.generateUIDforDevice(deviceId, sastoken);
        await customerDetailsPage.filldeviceName(localAet);
        await customerDetailsPage.fillIpAddress("101.101.101.101");
        await customerDetailsPage.selectDeviceIdentifier("04049471092080 (IOLMaster 700)");
        await customerDetailsPage.fillDeviceSerial(localSerialNumber);
        await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
        await customerDetailsPage.toggleWhitelistDevice("true");
        await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
        await customerDetailsPage.applyAllChanges();


        var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
        var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localAet);

        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.name)).toEqual(localAet)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.aetitle)).toEqual("null")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.ip)).toEqual("101.101.101.101")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.port)).toEqual("null")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.location)).toEqual(universalLocation)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceSerial)).toEqual(localSerialNumber)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceIdentifier)).toEqual("04049471092080 (IOLMaster 700)");
        await TestData.waitFortimeOut(15000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices = iothubResponse.data[0].properties.desired.connectedDevices
        expectedJSON = {
            "ip": "101.101.101.101",
            "name": localAet,
            "modality": "OPT: Ophthalmic Tomography",
            "sgc": universallocIDfromResp,
            "sn": localSerialNumber,
            "di": "04049471092080 (IOLMaster 700)",
            "st": "STREAMING",
            "whitelisted": 1
        }
        var latestHashCode
        let keyArray = new Array();
        keyArray = Object.keys(iotHubConnectedDevices);
        if (keyArray.length < 1) {
            latestHashCode = keyArray[keyArray.length];
        } else {
            latestHashCode = keyArray[keyArray.length - 1];
        }
        if (iotHubConnectedDevices.hasOwnProperty(latestHashCode)) {
            iothubJSON = iotHubConnectedDevices[latestHashCode];
            delete iothubJSON.fid;
            delete iothubJSON.snc;
            delete iothubJSON.port;
            delete iothubJSON.aet;
            delete iothubJSON.uid;
            delete iothubJSON.acuid;
            console.log('iothubJSON', iothubJSON);
            console.log('expectedJSON', expectedJSON);
            await areEqual.push(await Comparisions.compareUnorderedJSONObjects(iothubJSON, expectedJSON));
        } else {
            areEqual.push(false)
        }
        expect(areEqual[0]).not.toContain(false)

    });

    //US#310324
    test('Regular user should be able to add a new streaming device successfully with diffrent device types @310324', async function () {
        await basePage.navigateToUrl("regularuser");
      
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        let actualData = JSON.parse("[{\"identifier\":\"04057748081118\",\"name\":\"Atlas 9000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04250668606731\",\"name\":\"VISUSCREEN 100\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087141\",\"name\":\"Cirrus 6000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null}]");

        for (let i = 0; i < actualData.length - 1; i++) {
            let localAet = await  TestData.generateUIDforDevice(deviceId, sastoken);
            let localSerialNumber = await TestData.generateSerialNumber();
            await TestData.waitFortimeOut(2000);
            await customerDetailsPage.addDeviceButtonClick();
            await customerDetailsPage.selectAddDeviceType("STREAMING");

            await TestData.waitFortimeOut(3000);
            await customerDetailsPage.filldeviceName(localAet);
            await customerDetailsPage.fillIpAddress("101.101.101.101");
            console.log("device Identifier: " + actualData[i].identifier)
            await customerDetailsPage.selectDeviceIdentifierWithID(actualData[i].identifier);
            await customerDetailsPage.fillDeviceSerial(localSerialNumber);
            await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
            await customerDetailsPage.toggleWhitelistDevice("true");
            await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
            await TestData.waitFortimeOut(2000);
            await customerDetailsPage.applyAllChanges();

            var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
            var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localAet);

            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.name)).toEqual(localAet)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.aetitle)).toEqual("null")
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.ip)).toEqual("101.101.101.101")
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.port)).toEqual("null")
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.location)).toEqual(universalLocation)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceSerial)).toEqual(localSerialNumber)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceIdentifier)).toEqual(actualData[i].identifier + " (" + actualData[i].name.toUpperCase() + ")");
        }
        });

    //US#310324
    test('Regular user should be able to add a new dicom and streaming device successfully with all the parameters and verify no banner is displayed @310324', async function () {
        let areEqual = new Array(), expectedJSON, iothubJSON;
        await basePage.navigateToUrl("regularuser");
       
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        await customerDetailsPage.addDeviceButtonClick();
        await customerDetailsPage.selectAddDeviceType("BOTH");
        let localSerialNumber = await TestData.generateSerialNumber();
        let localAet = await TestData.generateUIDforDevice(deviceId, sastoken);
        await customerDetailsPage.fillAeTitle(localAet);
        await customerDetailsPage.fillPort("8080");
        await customerDetailsPage.filldeviceName(localAet);
        await customerDetailsPage.fillIpAddress("101.101.101.101");
        await customerDetailsPage.selectDeviceIdentifier("04049471092080 (IOLMaster 700)");
        await customerDetailsPage.fillDeviceSerial(localSerialNumber);
        await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
        await customerDetailsPage.toggleWhitelistDevice("true");
        await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
        await customerDetailsPage.applyAllChanges();


        var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
        var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localAet);

        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.name)).toEqual(localAet)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.aetitle)).toEqual(localAet)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.ip)).toEqual("101.101.101.101")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.port)).toEqual("8080")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.location)).toEqual(universalLocation)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceSerial)).toEqual(localSerialNumber)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceIdentifier)).toEqual("04049471092080 (IOLMaster 700)");
        await TestData.waitFortimeOut(20000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices = iothubResponse.data[0].properties.desired.connectedDevices
        expectedJSON = {
            "ip": "101.101.101.101",
            "name": localAet,
            "sgc": universallocIDfromResp,
            "sn": localSerialNumber,
            "di": "04049471092080 (IOLMaster 700)",
            "st": "BOTH",
            "whitelisted": 1
        }
        var latestHashCode
        let keyArray = new Array();
        keyArray = Object.keys(iotHubConnectedDevices);
        if (keyArray.length < 1) {
            latestHashCode = keyArray[keyArray.length];
        } else {
            latestHashCode = keyArray[keyArray.length - 1];
        }
        if (iotHubConnectedDevices.hasOwnProperty(latestHashCode)) {
            iothubJSON = iotHubConnectedDevices[latestHashCode];
            delete iothubJSON.fid;
            delete iothubJSON.snc;
            delete iothubJSON.port;
            delete iothubJSON.aet;
            delete iothubJSON.uid;
            delete iothubJSON.acuid;
            console.log('iothubJSON', iothubJSON);
            console.log('expectedJSON', expectedJSON);
            await areEqual.push(await Comparisions.compareUnorderedJSONObjects(iothubJSON, expectedJSON));
        } else {
            areEqual.push(false)
        }
        expect(areEqual[0]).not.toContain(false)

        areEqual = new Array();
        let dicomiothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
        let dicomiotHubConnectedDevices = dicomiothubResponse.data[0].properties.desired.connectedDevices
        expectedJSON = {
            "port": "8080",
            "ip": "101.101.101.101",
            "name": localAet,
            "uid": localAet,
            "acuid": "10101Updt",
            "modality": "OPT: Ophthalmic Tomography",
            "whitelisted": 0,
            "sgc": universallocIDfromResp,
            "aet": localAet,
            "sn": localSerialNumber,
            "di": "04049471092080"
        }
        if (dicomiotHubConnectedDevices.hasOwnProperty(localAet)) {
            iothubJSON = dicomiotHubConnectedDevices[localAet];

            expect(iothubJSON.fid).not.toBeNull();
            expect(iothubJSON.snc).not.toBeNull();
            expect(iothubJSON.di).not.toBeNull();

            delete iothubJSON.fid;
            delete iothubJSON.snc;
            delete iothubJSON.di;

            areEqual.push(Comparisions.compareUnorderedJSONObjects(iothubJSON, expectedJSON));
        } else {
            areEqual.push(false)
        }
        expect(areEqual).not.toContain(false);

    });

    //US#310324
    test('Regular user should be able to add a new dicom and streaming device successfully with diffrent device types @310324', async function () {
        await basePage.navigateToUrl("regularuser");
   
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        let actualData = JSON.parse("[{\"identifier\":\"04057748081118\",\"name\":\"Atlas 9000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04250668606731\",\"name\":\"VISUSCREEN 100\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04250668606724\",\"name\":\"VISUSCREEN 500\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049471097139\",\"name\":\"Visuref 150\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087080\",\"name\":\"Cirrus 5000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087097\",\"name\":\"Cirrus 500\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087141\",\"name\":\"Cirrus 6000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null}]");

        for (let i = 0; i < actualData.length - 1; i++) {
            let localAet = await await TestData.generateUIDforDevice(deviceId, sastoken);
            let localSerialNumber = await TestData.generateSerialNumber();
            await TestData.waitFortimeOut(2000);
            await customerDetailsPage.addDeviceButtonClick();
            await customerDetailsPage.selectAddDeviceType("BOTH");

            await TestData.waitFortimeOut(3000);
            await customerDetailsPage.fillAeTitle(localAet);
            await customerDetailsPage.fillPort("8080");
            await customerDetailsPage.filldeviceName(localAet);
            await customerDetailsPage.fillIpAddress("101.101.101.101");
            console.log("device Identifier: " + actualData[i].identifier)
            await customerDetailsPage.selectDeviceIdentifierWithID(actualData[i].identifier);
            await customerDetailsPage.fillDeviceSerial(localSerialNumber);
            await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
            await customerDetailsPage.toggleWhitelistDevice("true");
            await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
            await TestData.waitFortimeOut(2000);
            await customerDetailsPage.applyAllChanges();
            await TestData.waitFortimeOut(2000);

            var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
            var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localAet);

            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.name)).toEqual(localAet)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.aetitle)).toEqual(localAet)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.ip)).toEqual("101.101.101.101")
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.port)).toEqual("8080")
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.location)).toEqual(universalLocation)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceSerial)).toEqual(localSerialNumber)
            await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceIdentifier)).toEqual(actualData[i].identifier + " (" + actualData[i].name.toUpperCase() + ")");
        }
    });

    //US#310324
    test('Regular user should be able to add a new dicom and streaming device successfully with all special chars in AEID and UID @310324', async function () {
        let areEqual = new Array(), expectedJSON, iothubJSON;

        await basePage.navigateToUrl("regularuser");

        await customerDetailsPage.selectCMInstance(deviceId);
        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        expect(await customerDetailsPage.getDeviceId()).toEqual(deviceId);

        await customerDetailsPage.addDeviceButtonClick();
        await customerDetailsPage.selectAddDeviceType("BOTH");
        let localSerialNumber = await TestData.generateSerialNumber();

        let localAet = await TestData.generateUIDforDevice(deviceId, sastoken);
        await customerDetailsPage.fillAeTitle(localAet + "!@#");
        await customerDetailsPage.fillPort("8080");
        await customerDetailsPage.filldeviceName(localAet);
        await customerDetailsPage.fillIpAddress("101.101.101.101");
        await customerDetailsPage.selectDeviceIdentifier("04049471092080 (IOLMaster 700)");
        await customerDetailsPage.fillDeviceSerial(localSerialNumber);
        await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
        await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
        await customerDetailsPage.toggleWhitelistDevice("true");
        await customerDetailsPage.applyAllChanges();

        var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
        var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localAet + "!@#");

        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.name)).toEqual(localAet)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.aetitle)).toEqual(localAet + "!@#")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.ip)).toEqual("101.101.101.101")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.port)).toEqual("8080")
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.location)).toEqual(universalLocation)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceSerial)).toEqual(localSerialNumber)
        await expect(actualDeviceDetails.get(OR.locators.customerDetailsPage.deviceHeaders.deviceIdentifier)).toEqual("04049471092080 (IOLMaster 700)");
        await TestData.waitFortimeOut(10000);
        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices = iothubResponse.data[0].properties.desired.connectedDevices
        expectedJSON = {
            "ip": "101.101.101.101",
            "name": localAet,
            "sgc": universallocIDfromResp,
            "sn": localSerialNumber,
            "di": "04049471092080 (IOLMaster 700)",
            "st": "BOTH",
            "whitelisted": 1
        }

        var latestHashCode
        let keyArray = new Array();
        keyArray = Object.keys(iotHubConnectedDevices);
        if (keyArray.length < 1) {
            latestHashCode = keyArray[keyArray.length];
        } else {
            latestHashCode = keyArray[keyArray.length - 1];
        }
        if (iotHubConnectedDevices.hasOwnProperty(latestHashCode)) {
            iothubJSON = iotHubConnectedDevices[latestHashCode];
            delete iothubJSON.fid;
            delete iothubJSON.snc;
            delete iothubJSON.port;
            delete iothubJSON.aet;
            delete iothubJSON.uid;
            delete iothubJSON.acuid;
            console.log('iothubJSON', iothubJSON);
            console.log('expectedJSON', expectedJSON);
            await areEqual.push(await Comparisions.compareUnorderedJSONObjects(iothubJSON, expectedJSON));
        } else {
            areEqual.push(false)
        }
        expect(areEqual[0]).not.toContain(false)

        areEqual = new Array();
        let dicomiothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
        let dicomiotHubConnectedDevices = dicomiothubResponse.data[0].properties.desired.connectedDevices
        expectedJSON = {
            "ip": "101.101.101.101",
            "name": localAet,
            "modality": "OPT: Ophthalmic Tomography",
            "sgc": universallocIDfromResp,
            "sn": localSerialNumber,
            "di": "04049471092080 (IOLMaster 700)",
            "st": "BOTH",
            "whitelisted": 1,
            "uid": localAet + "!@#",
            "acuid": localAet + "!@#",
            "aet": localAet + "!@#",
            "di": "04049539104410"
        }
        if (dicomiotHubConnectedDevices.hasOwnProperty(localAet + "!@#")) {
            iothubJSON = dicomiotHubConnectedDevices[localAet + "!@#"];

            expect(iothubJSON.fid).not.toBeNull();
            expect(iothubJSON.snc).not.toBeNull();
            expect(iothubJSON.di).not.toBeNull();

            delete iothubJSON.fid;
            delete iothubJSON.snc;
            delete iothubJSON.di;

            areEqual.push(Comparisions.compareUnorderedJSONObjects(iothubJSON, expectedJSON));
        } else {
            areEqual.push(false)
        }
        expect(areEqual[0]).not.toContain(false);
    });

    // US#310324
    test('Regular user should successfully delete the streaming existing device type from the UI List @310324', async function () {
        await basePage.navigateToUrl("regularuser");
     
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        expect(await customerDetailsPage.getDeviceId()).toEqual(deviceId);
        let localUID = await TestData.generateUIDforDevice(deviceId, sastoken);
        await customerDetailsPage.addDeviceButtonClick();
        await customerDetailsPage.selectAddDeviceType("STREAMING");
        await customerDetailsPage.filldeviceName(localUID);
        await customerDetailsPage.fillIpAddress("101.101.101.101");
        await customerDetailsPage.selectDeviceIdentifier("04049471092080 (IOLMaster 700)");
        await customerDetailsPage.fillDeviceSerial(await TestData.generateSerialNumber());
        await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
        await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
        await customerDetailsPage.toggleWhitelistDevice("true");
        await customerDetailsPage.applyAllChanges();

        var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();

        await customerDetailsPage.deleteDeviceButton(activeDevicesTable, localUID);
        await customerDetailsPage.confirmDeleteDevice();

        activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
        var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localUID);

        expect(await actualDeviceDetails.size).toEqual(0);

    });


    // US#412586
    test('Regular user should successfully delete the Both existing device Type from the UI List @412586', async function () {
        await basePage.navigateToUrl("regularuser");
       
        await customerDetailsPage.selectCMInstance(deviceId);

        await customerDetailsPage.selectCMInstanceDevices(deviceId);
        expect(await customerDetailsPage.getDeviceId()).toEqual(deviceId);
        let localUID = await TestData.generateUIDforDevice(deviceId, sastoken);
        await customerDetailsPage.addDeviceButtonClick();
        await customerDetailsPage.selectAddDeviceType("BOTH");
        await customerDetailsPage.filldeviceName(localUID);
        await customerDetailsPage.fillAeTitle(localUID);
        await customerDetailsPage.fillIpAddress("101.101.101.101");
        await customerDetailsPage.fillPort("63331");
        await customerDetailsPage.selectDeviceIdentifier("04049471092080 (IOLMaster 700)");
        await customerDetailsPage.fillDeviceSerial(await TestData.generateSerialNumber());
        await customerDetailsPage.selectModality("OPT: Ophthalmic Tomography");
        await customerDetailsPage.selectDeviceLocation(universallocIDfromResp);
        await customerDetailsPage.toggleWhitelistDevice("true");
        await customerDetailsPage.applyAllChanges();
        var activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();

        await customerDetailsPage.deleteDeviceButton(activeDevicesTable, localUID);
        await customerDetailsPage.confirmDeleteDevice();

        activeDevicesTable = await customerDetailsPage.getActiveDevicesTable();
        var actualDeviceDetails = await customerDetailsPage.getDeviceFromDevicesTable(activeDevicesTable, localUID);

        expect(await actualDeviceDetails.size).toEqual(0);


    });
    test.afterAll(async function () {
        //delete the exisiting connected devices 
        token = await TokenGenerators.generateAuthToken("regularuser");
        await ApiHelper.deleteAll_ActiveDevice(token, deviceId);
        await ApiHelper.deleteAll_InActiveDevice(token, deviceId);
        await ApiHelper.deleteAll_AutomationDeviceLocations(token, customerId);

    });

});


