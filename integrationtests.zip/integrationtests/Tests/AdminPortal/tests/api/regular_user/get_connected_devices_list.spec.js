const { TokenGenerators } = require('../../../utils/token_generators.js');
const { Comparisions } = require('../../../utils/comparisions.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
var OR = require('../../../resources/OR.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')

const apimConnectedDevicesListURL = process.env.apimBaseURL + OR.APIUrls.connectedDevicesUrl;
var sastoken, deviceId, token, conn, response, locIDfromResp,customerDetailsId,customerDetailsRecordSet,customerId,customer;
var l1TestDevice = process.env.serviceUserHypervDeviceId

test.describe("Connected Devices List API for regular users",function(){
    test.beforeAll(async function(){
        // test data preparation   
        conn = await TestData.sqlDBConnection();
        var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId = '5985') and activationStatus='True' for json auto")
        var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        token = await TokenGenerators.generateAuthToken("regularuser")
    });
    //US#124751
    test("Regular users should NOT fetch all the connected devices of a specified device @124751", async function(){
       
        //api request
        var config = {  
            method: 'get',
            url: apimConnectedDevicesListURL+"/"+deviceId+"/connected-devices",
          
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        expect(response.status).toBe(200);

        
    });
    //US#124751
    test("Regular users should return 400 when non-existing device is passed as parameter @124751", async function(){
        //getting connected devices details using non-existing device id
        response = await ApiHelper.getConnectedDevices(token, "randomInvalidDeviceId")
        var responseData = response.data
        expect(response.status).toBe(400);
        expect(responseData).toBe("Invalid device id.");
        

    });
    //US#124751
    test("Regular users should return error when an deviceId is not passed as parameter @124751", async function(){
        var config = {  
            method: 'get',
            url: apimConnectedDevicesListURL+"/connected-devices",
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        expect(response.status).toBe(404);
    });
    //US#124751
    test("Regular users should return error when empty device is passed as parameter @124751", async function(){
         //getting connected devices details using empty device id
         response = await ApiHelper.getConnectedDevices(token, " ")
         var responseData = response.data
         expect(response.status).toBe(400);
         expect(responseData).toBe('IotDevice Id should not be empty.');
    });

    //US#344323
    test("API- Validate various API error codes for regularuser to get the Connected Devices Detail @344323", async function ({page}) {
    //getting Connected Devices using regular user for restricted customer
    let newResponse = await ApiHelper.getConnectedDevices(token, l1TestDevice)
    expect(newResponse.status).toBe(403);  
    //getting Connected Devices using invalid token      
    var invalidToken = 'abcd'
    newResponse = await ApiHelper.getConnectedDevices(invalidToken, l1TestDevice)
    expect(newResponse.status).toBe(401);
  
  });
    
});