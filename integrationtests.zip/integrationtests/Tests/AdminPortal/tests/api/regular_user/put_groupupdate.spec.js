const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
var OR = require('../../../resources/OR.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')

const apimGroupUpdateURL = process.env.apimBaseURL + OR.APIUrls.groupUpdateUrl;
var deviceId, token, conn, updatedGroupId, groupId, sastoken, newResponse;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
var l1TestDevice = process.env.serviceUserHypervDeviceId

test.describe("GroupUpdate API for regular users", function () {
    test.beforeAll(async function () {
        // test data preparation   
        conn = await TestData.sqlDBConnection();
        var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId = '5985') and activationStatus='True' for json auto")
        var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        groupId = deviceRecord[0].groupId;
        token = await TokenGenerators.generateAuthToken("regularuser")
        sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)
    });
    test.beforeEach(async function () {
        if (groupId == 1) {
            updatedGroupId = 2
        } else if (groupId == 2) {
            updatedGroupId = 3
        } else if (groupId == 3) {
            updatedGroupId = 1
        }
    })
    //US#177339
    test("GroupUpdate API should be able to update the timeframe group for updates for regular user @177339", async function () {

        //api request
        let response = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, deviceId, updatedGroupId);
        expect(response.status).toBe(200);
        conn = await TestData.sqlDBConnection();
        var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotDeviceId='" + deviceId + "' for json auto");
        var devicesRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        expect(devicesRecord[0].groupId).toEqual(updatedGroupId);

    });
    //US#177339
    test("GroupUpdate API should be NOT able to update the timeframe group when invalid deviceId is passed for regular user @177339", async function () {
        //api request
        let response = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, 'InvalidDeviceId', updatedGroupId);
        expect(response.status).toBe(400);
        expect(response.data).toBe("Invalid device id.");

    });
    //US#177339
    test("GroupUpdate API should be NOT able to update the timeframe group when invalid groupId is passed for regular user @177339", async function () {
        //api request
        let response = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, deviceId, 12);
        expect(response.status).toBe(400);
    });
    //US#177339
    test("GroupUpdate API should throw error when empty deviceId is passed for regular user @177339", async function () {
        let response = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, ' ', updatedGroupId);
        expect(response.status).toBe(400);
        expect(response.data).toEqual("IotDevice Id should not be empty.");
    });
    //US#177339
    test("GroupUpdate API should throw error when empty groupId is passed for regular user @177339", async function () {
        let response = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, deviceId, " ");
        expect(response.status).toBe(400);
        expect(response.data).toEqual("Group Id should not be empty.");
    });

    //US#344323
    test("API- Validate various API error codes for regularuser to select timeframe @344323", async function ({ page }) {
        //Selecting Timeframe using regular user for restricted customer
        newResponse = await ApiHelper.selectTimeframeUpdateGroupAssociate(token, l1TestDevice, 2)
        expect(newResponse.status).toBe(403);
        //Selecting Timeframe using invalid token                             
        var invalidToken = 'abcd'
        newResponse = await ApiHelper.selectTimeframeUpdateGroupAssociate(invalidToken, l1TestDevice, 2)
        expect(newResponse.status).toBe(401);
    });

});