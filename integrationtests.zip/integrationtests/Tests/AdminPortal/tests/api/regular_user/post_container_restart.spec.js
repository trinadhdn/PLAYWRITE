const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
const { IotHubMethods } = require('../../../utils/iothub_methods.js');
const { ApiHelper } = require('../../../helpers/api-helpers.js');
let ErrorMSG = require('../../../resources/ErrorMSG.json');
var OR = require('../../../resources/OR.json');

const apimContainerRestartURL = process.env.apimBaseURL + OR.APIUrls.containerRestartURL;
var conn,token,deviceId,sastoken;
var hypervDeviceId = process.env.regularUserHypervDeviceId;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'


test.describe("Container Restart API", function () {
  test.beforeAll(async function () {
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId ='" + hypervDeviceId + "' and activationStatus='True' for json auto")
    var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    deviceId = deviceRecord[0].iotDeviceId;
    token = await TokenGenerators.generateAuthToken("regularuser");
    sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)

  })

  // US#308181
  test("Regularuser should not restart the custom modules when we pass the valid device ID, Module ID @308181", async function () {

    var iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, '$edgeAgent', sastoken);
    var desiredCustomModulesJson = iothubResponse.data[0].properties.desired.modules
    var customModulesJson = iothubResponse.data[0].properties.reported.modules
    var customModules = [...new Set([...Object.keys(desiredCustomModulesJson), ...Object.keys(customModulesJson)])]
    for (let i = 0; i < customModules.length; i++) {
      var restartResponse = await ApiHelper.postContainerRestart(token, deviceId, customModules[i])
      expect(restartResponse.status).toBe(403);
      expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);
    }

  });

  // US#308181
  test("Regularuser should not restart the EdgeHub container when we pass the valid device ID, Module ID @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + deviceId + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "edgeHub" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);

  });

  // US#308181
  test("Regularuser should not be able to restart the EdgeAgent container when we pass the valid device ID, Module ID @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + deviceId + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "edgeAgent" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);
  });

  // US#308181
  test("Regularuser Restart API should return bad request error when we pass the valid device ID, invalid Module ID @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + deviceId + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "abcmodule" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);
  });


  // US#308181
  test("Regularuser Restart API should return bad request error when we pass the valid invalid device ID, valid Module ID @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + "12345" + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "zvimodule" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);
  });


  // US#308181
  test("Regularuser Restart API should return bad request error when we pass the invalid device ID, invalid Module ID @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + "12345" + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "abcmodule" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);
  });

  // US#308181
  test("Regular User Restart API should return bad request error when we pass the null Modules ID  @308181", async function () {
    var config = {
      method: 'post',
      url: apimContainerRestartURL + "/" + deviceId + "/container-restart",
      headers: { "Authorization": "Bearer " + token },
      data: { "moduleName": "" }
    };

    var restartResponse = await TokenGenerators.request(config);
    expect(restartResponse.status).toBe(403);
    expect(restartResponse.data).toBe(ErrorMSG.ErrorMsg_403);

  });

});