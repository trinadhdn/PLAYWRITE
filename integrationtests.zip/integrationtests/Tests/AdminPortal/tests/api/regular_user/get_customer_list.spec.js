const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js'); 
var OR = require('../../../resources/OR.json');

const apimCustomerListURL = process.env.apimBaseURL + OR.APIUrls.customerListUrl;
var token,customerName,customerId;

test.describe("Customer List API for regular user",function(){
  test.beforeAll(async function(){
    token = await TokenGenerators.generateAuthToken("regularuser")
  })
  
  // US#124751
  test("should NOT fetch the customers with regular user @124751", async function(){
    var config = {  
      method: 'get',
      url: apimCustomerListURL,
      headers: { "Authorization": "Bearer "+token },
    };
    
    var response = await TokenGenerators.request(config);
    expect(response.status).toBe(403);
   

  });

  // US#124751
  test("when customerName filter key is provided with regular user, should NOT fetch the items @124751", async function() {
    var conn = await TestData.sqlDBConnection();
    var customerRecordSet = await TestData.executeSqlQuery(conn,"SELECT top(1) * FROM CustomerDetails where customerId='5985' for json auto")
    var customerRecord = JSON.parse(customerRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    customerName = customerRecord[0].customerName
    var config = {  
      method: 'get',
      url: apimCustomerListURL,
      params: {
        filterKey: customerName
      },
      headers: { "Authorization": "Bearer "+token },
    };
    
    var response = await TokenGenerators.request(config);
    expect(response.status).toBe(403);

  });

  // US#124751
  test("when customerID filter key is provided with regular user, should NOT fetch the items @124751", async function() {
    var conn = await TestData.sqlDBConnection();
    var customerRecordSet = await TestData.executeSqlQuery(conn,"SELECT top(1) * FROM CustomerDetails where customerId='5985' for json auto")
    var customerRecord = JSON.parse(customerRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    customerId = customerRecord[0].customerId
    var config = {  
      method: 'get',
      url: apimCustomerListURL,
      params: {
        filterKey: customerId
      },
      headers: { "Authorization": "Bearer "+token },
    };
    
    var response = await TokenGenerators.request(config);
    expect(response.status).toBe(403);

  });
});