const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js'); 
var OR = require('../../../resources/OR.json');

const apimOSSLicensesURL = process.env.apimBaseURL + OR.APIUrls.cmPackageLicense;
var token;

test.describe("OSS Licenses statement API for regular user",function(){
  test.beforeAll(async function(){
    token = await TokenGenerators.generateAuthToken("regularuser")
  })
  
  // US#98432
  test("should fetch the OSS Licenses statement with Regular user @98432", async function(){
    var config = {  
      method: 'get',
      url: apimOSSLicensesURL,
      headers: { "Authorization": "Bearer "+token },
    };
    
    var response = await TokenGenerators.request(config);
    expect(response.status).toBe(200);
    expect(response.data.length).not.toBe(0);


  });

  
});