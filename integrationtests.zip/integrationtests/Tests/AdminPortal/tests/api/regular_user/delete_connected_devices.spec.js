const { IotHubMethods } = require('../../../utils/iothub_methods.js');
const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
let OR = require('../../../resources/OR.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')
const { TestData } = require('../../../utils/test_data.js');

const apimAddConnectedDevicesUrl = process.env.apimBaseURL + OR.APIUrls.addConnectedDevicesUrl;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
let sastoken, token, l1usertoken,locIDfromRespl1,locIDfromResp,customer,customerId, newResponse,conn,customerDetailsId,customerDetailsRecordSet;
let deviceId = process.env.regularUserHypervDeviceId;
var l1TestDevice = process.env.serviceUserHypervDeviceId

test.describe("Delete Connected Devices API for regularuser", function () {
    test.beforeAll(async function () {
        // test data preparation     
        sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)
        token = await TokenGenerators.generateAuthToken("regularuser");
        l1usertoken = await TokenGenerators.generateAuthToken("l1serviceuser");
        conn = await TestData.sqlDBConnection();
        let devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId = '" + deviceId + "' for json auto")
        let deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        customerDetailsId = deviceRecord[0].customerDetailsId;
        conn = await TestData.sqlDBConnection();
        customerDetailsRecordSet = await TestData.executeSqlQuery(conn, "select * from [dbo].[CustomerDetails] where customerdetailsId=" + customerDetailsId + " for json auto")
        var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        customerId = customerDetailsRecord[0].customerId;
        customer = customerDetailsRecord[0].customerName;
        console.log("customerId: " + customerId)
        console.log("deviceId: " + deviceId)
        // create location-->
        var locName = "AutoLoc-RDel-ConDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;
        var postresponse2 = await ApiHelper.postlocationList(l1usertoken, "6100", locName, locDesc, status)
        expect(postresponse2.status).toBe(200);
        locIDfromRespl1 = postresponse2.data.result.id;
    })

    //US#307793
    test("API Regular user should be able to delete the device and then device should be deleted from FHIR service as well as module twin @307793", async function () {
        let globalUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        let globalAet = globalUid;
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("DICOM", token, deviceId, "1010", "iol1.customer.internal.com", "AutDevic10150", globalUid, locIDfromResp,"10105", "OPT: Ophthalmic Tomography", 1, globalAet, localSerialNumber, "04049539104410(CALLISTO eye)",)
        expect(response.status).toBe(200);
        let deleteResponse = await ApiHelper.deleteDevice("DICOM", token, deviceId, globalUid)
        expect(deleteResponse.status).toBe(200)

        await TestData.waitFortimeOut(5000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
        let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(globalUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);

    })

    //US#344323 

    test("API- Validate various API error codes for regularuser for delete dicom device @344323", async function ({ page }) {
        //Create dicom device using l1user
        let localSerialNumber = await TestData.generateSerialNumber();
        newResponse = await ApiHelper.addDevice("DICOM", l1usertoken, l1TestDevice, '1111', '198.0.0.1', 'devicename', '1234',locIDfromRespl1, '5555', 'OPT: Ophthalmic Tomography', 1, 'aetitle', localSerialNumber, '(Others)', '343456')
        expect(newResponse.status).toBe(200);
        //update created device using regular user to check that status code is 403
        newResponse = await ApiHelper.deleteDevice("DICOM", token, l1TestDevice, '1234')
        TestData.waitFortimeOut(5000);
        expect(newResponse.status).toBe(403);
        //deleting dicom device with invalid token to verify 401 status code.    
        var invalidToken = 'abcd'
        newResponse = await ApiHelper.deleteDevice("DICOM", invalidToken, l1TestDevice, '1234')
        expect(newResponse.status).toBe(401);
        //deleting the created device
        newResponse = await ApiHelper.deleteDevice("DICOM", l1usertoken, l1TestDevice, '1234')
        TestData.waitFortimeOut(5000);
        expect(newResponse.status).toBe(200);
    });

    //US#307793
    test("API - With regular user_API Should throw error when deviceID is missing or invalid / validating different error codes @307793", async function () {

        let globalUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        let globalAet = globalUid;
        console.log(globalUid);
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("DICOM", token, deviceId, "1010", "iol1.customer.internal.com", "AutDevic10150", globalUid,locIDfromResp, "10105", "OPT: Ophthalmic Tomography", 1, globalAet, localSerialNumber, "04049539104410(CALLISTO eye)",)

        expect(response.status).toBe(200);

        let deleteResponse = await ApiHelper.deleteDevice("DICOM", token, " ", globalUid)
        expect(deleteResponse.status).toBe(400);
        expect (deleteResponse.data.errorMessage).toBe("IotDevice Id should not be empty.")

        let deleteinvalidResponse = await ApiHelper.deleteDevice("DICOM", token, "invalid", globalUid)
        expect(deleteinvalidResponse.status).toBe(400);
        expect(deleteinvalidResponse.data.errorMessage).toBe('Invalid device id.');

        let deleteLatestResponse = await ApiHelper.deleteDevice("DICOM", token,deviceId, globalUid)
        expect(deleteLatestResponse.status).toBe(200);

        await TestData.waitFortimeOut(15000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
        let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(globalUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);

    })
   

    test.afterAll(async function () {
        await ApiHelper.deleteAll_ActiveDevice(token, deviceId)
        await ApiHelper.deleteAll_InActiveDevice(token, deviceId)
        
        //Delete All Location --->
        await ApiHelper.deleteAll_AutomationDeviceLocations(token, customerId);

    });

})