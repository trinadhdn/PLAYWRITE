const { TokenGenerators } = require('../../../utils/token_generators.js');
const { Comparisions } = require('../../../utils/comparisions.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
var OR = require('../../../resources/OR.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')

const apimConnectivityModuleListURL = process.env.apimBaseURL + OR.APIUrls.connectivityModuleListUrl;
var token,customerDetailsId,custId,conn,customerDetailsRecordSet;
var l1TestDevice = process.env.serviceUserHypervDeviceId

test.describe("Connectivity Module List API for regular user",function(){
    test.beforeAll(async function(){
        // test data preparation     
        conn = await TestData.sqlDBConnection();
        customerDetailsRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[CustomerDetails] where customerId='5985' for json auto")
        var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        custId = customerDetailsRecord[0].customerId;
        customerDetailsId = customerDetailsRecord[0].customerDetailsId;
        token = await TokenGenerators.generateAuthToken("regularuser")
    });
    //US#124751
    test("Regular users should fetch only the connectivity module instances for the provided customerId @124751 @177412", async function(){
        conn = await TestData.sqlDBConnection();
        var recordSet = await TestData.executeSqlQuery(conn,"SELECT deviceId,iotDeviceId,activationStatus,groupId from [dbo].[Device] where customerDetailsId ='"+customerDetailsId+"' ORDER By deviceId ASC for json auto");
        var dbData = JSON.parse(recordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        var config = {  
            method: 'get',
            url: apimConnectivityModuleListURL+"/"+custId+"/devices",
           
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        var apiData = response.data
        var areEqual= new Array(), apiJSON,dbJSON;
        expect(response.status).toBe(200);
        if(apiData.length <= dbData.length){
            for(var i=0;i < apiData.length; i++){               
                apiJSON = JSON.parse(JSON.stringify(apiData[i]));
                dbJSON = JSON.parse(JSON.stringify(dbData[i]));
                areEqual.push(Comparisions.compareObjects(apiJSON,dbJSON));
            }
        } else {
            areEqual.push(false);
        }
        expect(areEqual).not.toContain(false);
    });
    //US#124751
    test("Regular users should throw an error when a Customer Id with special characters is passed as parameter @124751 @177412", async function(){
        var config = {  
            method: 'get',
            url: apimConnectivityModuleListURL+"/"+"Hello&123"+"/devices",
        
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        expect(response.status).toBe(403);
    });
    //US#124751
    test("Regular users should throw an error when a Customer Id is NOT passed as parameter @124751 @177412", async function(){
        var config = {  
            method: 'get',
            url: apimConnectivityModuleListURL+"/"+""+"/devices",
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        expect(response.status).toBe(404);
    });
    //US#124751
    test("Regular users should throw an error when empty Customer Id is passed as parameter @124751 @177412", async function(){
        var config = {  
            method: 'get',
            url: apimConnectivityModuleListURL+"/"+" "+"/devices",
           
            headers: { "Authorization": "Bearer "+token },
        };

        var response = await TokenGenerators.request(config);
        expect(response.status).toBe(400);
        expect(response.data).toBe('Customer Id should be not empty.');
   
    });

    //US#344323
    test("API- Validate various API error codes for regularuser to get the Device Detail @344323", async function ({page}) {
    //getting Device Detail using regular user for restricted customer
    let newResponse = await ApiHelper.getDevice(token, l1TestDevice)
    expect(newResponse.status).toBe(403);    
    //getting Device Detail using invalid token          
    var invalidToken = 'abcd'
    newResponse = await ApiHelper.getDevice(invalidToken, l1TestDevice)
    expect(newResponse.status).toBe(401);
      
      });
  
});