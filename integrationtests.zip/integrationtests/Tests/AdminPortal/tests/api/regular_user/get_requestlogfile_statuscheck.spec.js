const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
var OR = require("../../../resources/OR.json");


const apimLogFileRequest = process.env.apimBaseURL + OR.APIUrls.requestLogFile;

var token, deviceId,conn;

test.describe("Log File Request for regular user", function(){
  test.beforeAll(async function () {
    // test data preparation
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId='5985') and activationStatus='True' for json auto")
    var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    deviceId = deviceRecord[0].iotDeviceId;
    console.log("iotDeviceId: " + deviceId);
    token = await TokenGenerators.generateAuthToken("regularuser");
  
  });

  // US#124751
  test("Regular user should NOT be allowed to successfully request the log files from Azure blob with valid deviceID @124751", async function(){
    var requestLogFileconfig = {
      method: "get",
      url: apimLogFileRequest+"/"+deviceId+"/log-files",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      }
     
    };
    var response = await TokenGenerators.request(requestLogFileconfig);
    expect(response.status).toBe(403);
    
  });


   // US#124751
   test("Regular user should be NOT be able to successfully request the log files from Azure blob with invalid deviceID @124751", async function(){
    var requestLogFileconfig = {
      method: "get",
      url: apimLogFileRequest+"/"+"deviceID"+"/log-files",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      }
    };
    var response = await TokenGenerators.request(requestLogFileconfig);
    expect(response.status).toBe(403);
 
  });
});
