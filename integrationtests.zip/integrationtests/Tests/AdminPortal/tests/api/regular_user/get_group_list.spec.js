const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
const { Comparisions } = require('../../../utils/comparisions.js');
var OR = require('../../../resources/OR.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')

const apimGroupListURL = process.env.apimBaseURL + OR.APIUrls.groupListURL;
var token, newResponse;

test.describe("Group List API", function () {
  test.beforeAll(async function () {
    token = await TokenGenerators.generateAuthToken("regularuser");
  })

  // US#177337
  test("GroupList API for RegularUser user should fetch all the available timeframe groups for updates @177337", async function () {
    var conn = await TestData.sqlDBConnection();
    var groupRecordSet = await TestData.executeSqlQuery(conn, "select groupId,groupName,groupCode,startTime,endTime,daysOfWeek from [dbo].[Group] for json auto");
    var dbData = JSON.parse(groupRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    let response = await ApiHelper.getGroups(token);
    var apiData = response.data
    var areEqual = new Array(), apiJSON, dbJSON;
    expect(response.status).toBe(200);
    console.log(JSON.stringify(apiData[0]));
    console.log(JSON.stringify(dbData[0]));
    if (apiData.length <= dbData.length) {
      for (var i = 0; i < apiData.length; i++) {

        apiJSON = JSON.parse(JSON.stringify(apiData[i]));
        dbJSON = JSON.parse(JSON.stringify(dbData[i]));
        areEqual.push(Comparisions.compareObjects(apiJSON, dbJSON));
      }
    } else {
      areEqual.push(false);
    }
    expect(areEqual).not.toContain(false);

  });

  //US#344323
  test("API- Validate various API error codes for regularuser to get the Group Detail @344323", async function ({ page }) {
    //getting Group List using regular user will give 200 as getting group list is independent of any device
    newResponse = await ApiHelper.getGroups(token)
    expect(newResponse.status).toBe(200);
    //getting Group List using invalid token               
    var invalidToken = 'abcd'
    newResponse = await ApiHelper.getGroups(invalidToken)
    expect(newResponse.status).toBe(401);
    expect(newResponse.data.statusCode).toBe(401);

  });
});