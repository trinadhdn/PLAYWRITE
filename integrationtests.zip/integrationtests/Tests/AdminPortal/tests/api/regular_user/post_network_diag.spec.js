const { TokenGenerators } = require('../../../utils/token_generators.js');
const { Comparisions } = require('../../../utils/comparisions.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
const { IotHubMethods } = require('../../../utils/iothub_methods.js');
const { ApiHelper } = require('../../../helpers/api-helpers.js')
var OR = require("../../../resources/OR.json");

const apimNetworkDiagRequest = process.env.apimBaseURL + OR.APIUrls.networkdiagnosis;
var token, deviceId, azureData, conn, sastoken, methodName, payload;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
var hypervDeviceId = process.env.regularUserHypervDeviceId;
var newdeviceId = "zidag-5985-6"
var InputVal = "8.8.8.8"

test.describe("Get Network Diagnosis Details", function () {
  test.beforeAll(async function () {
    // test data preparation
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId ='" + hypervDeviceId + "' and activationStatus='True' for json auto")
    var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    deviceId = deviceRecord[0].iotDeviceId;
    console.log("deviceId: " + deviceId);
    token = await TokenGenerators.generateAuthToken("regularuser");
    sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)
    methodName = 'NetworkDiagnosis'
    payload = { "diagnosisType": "Ping", "destinationAddress": "127.0.0.1" }
  });

  // US#308176
  test("Regular user should NOT be able to successfully request the Network Diagnosis Details with valid details @308176", async function () {
    var response = await ApiHelper.postNetworkDiagnosisResp(token, deviceId, "Ping", InputVal);
    expect(response.status).toBe(403);

  });

  // US#308176
  test("Regular user should not be able to request the Traceroute Network Diagnosis Details with valid details trace method @308176", async function () {

    var response = await ApiHelper.postNetworkDiagnosisResp(token, deviceId, "TraceRoute", "127.0.0.1");
    expect(response.status).toBe(403);


  });

  // US#308176
  test("Regular user should not be able to request the Network Diagnosis Details for not owned device @308176", async function () {

    var response = await ApiHelper.postNetworkDiagnosisResp(token, newdeviceId, "TraceRoute", "127.0.0.1");
    expect(response.status).toBe(403);


  });





});
