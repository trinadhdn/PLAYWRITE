var OR = require("../../../resources/OR.json");
const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js'); 

const apimuploadLogs = process.env.apimBaseURL + OR.APIUrls.uploadLogs;

var token, apimoduleName, deviceId,conn;

test.describe("Upload Logs API for Regular user", function(){
  test.beforeAll(async function () {
    // test data preparation
    conn = await TestData.sqlDBConnection();
    var devicesRecordSet = await TestData.executeSqlQuery(conn,"select top(1) * from [dbo].[Device] where customerDetailsId in (select customerDetailsId from [dbo].[CustomerDetails] where customerId = '5985') and activationStatus='True' for json auto")
    var deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
    deviceId = deviceRecord[0].iotDeviceId;
    token = await TokenGenerators.generateAuthToken("regularuser");
  });

  // US#124751
  test("Regular user should be able to create new logs for the given filters and check the status @124751", async function () {
    var moduleNamesForTest = [
      "management",
      "zvimodule",
      "dicomforwardermodule",
      "allModules",
      "Nofilters",
      "nologForCriteria",
    ];
    for (var k = 0; k < moduleNamesForTest.length; k++) {
      apimoduleName = moduleNamesForTest[k];
      var requestPayload;
      var contextType = ["json", "text"];
      if (apimoduleName == "allModules") {
        requestPayload = {
          modules: [
            {
              moduleName: "zvimodule",
              filter: {
                since: Math.round(
                  new Date().setFullYear(new Date().getFullYear() - 1) / 1000
                ),
                tail: Math.round(Math.random() * (1000000 - 1000) + 1000),
                until: Math.round(new Date().getTime() / 1000),
              },
            },
            {
              moduleName: "managementmodule",
              filter: {
                tail: Math.round(Math.random() * (1000000 - 1000) + 1000),
                until: Math.round(new Date().getTime() / 1000),
                loglevel: Math.round(Math.random() * (7 - 1) + 1),
              },
            },
            {
              moduleName: "dicomforwardermodule",
              filter: {
                tail: Math.round(Math.random() * (1000000 - 1000) + 1000),
                until: Math.round(new Date().getTime() / 1000),
              },
            },
          ],
          iotDeviceId: deviceId,
          contentType:
            contextType[Math.floor(Math.random() * contextType.length)],
        };
      } else if (apimoduleName == "Nofilters") {
        requestPayload = {
          modules: [
            {
              moduleName: "management",
              filter: {},
            },
          ],
          contentType:
            contextType[Math.floor(Math.random() * contextType.length)],
        };
      } else if (apimoduleName == "nologForCriteria") {
        requestPayload = {
          modules: [
            {
              moduleName: "management",
              filter: {
                loglevel: 10,
              },
            },
          ],
          contentType:
            contextType[Math.floor(Math.random() * contextType.length)],
        };
      } else
        requestPayload = {
          modules: [
            {
              moduleName: apimoduleName,
              filter: {
                since: Math.round(
                  new Date().setFullYear(new Date().getFullYear() - 1) / 1000
                ),
                tail: Math.round(Math.random() * (1000000 - 1000) + 1000),
                until: Math.round(new Date().getTime() / 1000),
              },
            },
          ],
          contentType:
            contextType[Math.floor(Math.random() * contextType.length)],
        };

      var uploadconfig = {
        method: "post",
        url: apimuploadLogs+"/"+deviceId+"/initiate-log-upload",
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
        data: requestPayload,
      };
      var response = await TokenGenerators.request(uploadconfig);
      expect(response.status).toBe(403);
    }
  });

  test("For regular user Verify uploadLog Api throws error for invalid payload @124751",async function () {
    var moduleNamesForTest = ["IncorrectPayload"];
    for (var k = 0; k < moduleNamesForTest.length; k++) {
      apimoduleName = moduleNamesForTest[k];
      var requestPayload;
      var contextType = ["json", "text"];
      if (apimoduleName == "IncorrectPayload") {
        requestPayload = {
          modules: {},
        };
      } else
        requestPayload = {
          modules: [
            {
              moduleName: apimoduleName,
              filter: {
                since: Math.round(
                  new Date().setFullYear(new Date().getFullYear() - 1) / 1000
                ),
                tail: Math.round(Math.random() * (1000000 - 1000) + 1000),
                until: Math.round(new Date().getTime() / 1000),
              },
            },
          ],
          iotDeviceId: deviceId,
          contentType:
            contextType[Math.floor(Math.random() * contextType.length)],
        };

      var uploadconfig = {
        method: "post",
        url: apimuploadLogs+"/"+deviceId+"/initiate-log-upload",
        headers: {
          Authorization: "Bearer ",
          "Content-Type": "application/json",
        },
        data: requestPayload,
      };
      var response = await TokenGenerators.request(uploadconfig);
      expect(response.status).toEqual(401);
    }
  });
});
