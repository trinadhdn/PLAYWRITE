const { TokenGenerators } = require('../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../utils/test_data.js');
let OR = require('../../../resources/OR.json');
let ErrorMSG = require('../../../resources/ErrorMSG.json');
let { ApiHelper } = require('../../../helpers/api-helpers.js')

const apimUpdateConnectedDevicesUrl = process.env.apimBaseURL + OR.APIUrls.updateConnectedDevicesUrl;
const apimAddConnectedDevicesUrl = process.env.apimBaseURL + OR.APIUrls.addConnectedDevicesUrl;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner';
var hypervDeviceId = process.env.regularUserHypervDeviceId;
var l1TestDevice = process.env.serviceUserHypervDeviceId
let sastoken, token, conn,deviceId, globalUid, globalAet, locIDfromResp, customerId, customer, customerDetailsId, customerDetailsRecordSet;
let newResponse, l1usertoken, locIDfromRespl1;

test.describe("Update Connected Devices API for regular user", function () {
    test.beforeAll(async function () {
        // test data preparation 
        conn = await TestData.sqlDBConnection();
        let devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId = '" + hypervDeviceId + "' for json auto")
        let deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        customerDetailsId = deviceRecord[0].customerDetailsId;
        conn = await TestData.sqlDBConnection();
        customerDetailsRecordSet = await TestData.executeSqlQuery(conn, "select * from [dbo].[CustomerDetails] where customerdetailsId=" + customerDetailsId + " for json auto")
        var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        customerId = customerDetailsRecord[0].customerId;
        customer = customerDetailsRecord[0].customerName;
        console.log("customerId: " + customerId)
        console.log("deviceId: " + deviceId)
        token = await TokenGenerators.generateAuthToken("regularuser");
        l1usertoken = await TokenGenerators.generateAuthToken("l1serviceuser");
        sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)
        // create location -->
        var locName = "AutoLoc-RPut-Device" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        // Regular user--->
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;
        // Service user -->
        var postresponse2 = await ApiHelper.postlocationList(l1usertoken, "6100", locName, locDesc, status)
        expect(postresponse2.status).toBe(200);
        locIDfromRespl1 = postresponse2.data.result.id;
        //Create a connected devices
        globalUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        globalAet = globalUid;
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("DICOM", token, deviceId, '1019', 'iol1.customer.internal.com', 'AutDevic10101', globalUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(200);
    });
    //US#124751
    test("Regular user should be able to update an existing device with all the parameters @124751 @310324", async function () {
        //api request
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1011', 'iol1.customer.internal.com', 'AutDevic10101Updt', globalUid, locIDfromResp, '10101Updt', 'OPM: Ophthalmic Mapping', 0, globalAet, localSerialNumber, '04049539102423 (CALLISTO eye 3.2.1 model I)',);
        expect(response.status).toBe(200);
    });

    //US#124751
    test("Regular user should not update device if the aet value matches with an existing connected device aet value @124751 @310324", async function () {

        let localUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        let localAet = localUid;
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let postResponse = await ApiHelper.addDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', localUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, localAet, localSerialNumber, '04049539104410 (CALLISTO eye)',);
        expect(postResponse.status).toBe(200);
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1011', 'iol10101upd.customer.internal.com', 'AutDevic10101Updt', globalUid, locIDfromResp, '10101Updt', 'OPM: Ophthalmic Mapping', 0, localAet, localSerialNumber, '04049539102423 (CALLISTO eye 3.2.1 model I)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4002);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4002);
    });

    //US#124751
    test("Regular user should not update existing device when deviceId is missing in Req@124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, ' ', '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4);

    });

    //US#124751
    test("Regular user should update an exisiting device with only mandatory parameters @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request 
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 0, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(200);

    });

    //US#124751
    test("Regular user should not update existing device when required parameter - uid is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10112', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', '', locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4020);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4020);

    });

    //US#124751
    test("Regular user should not update existing device when required parameter - port is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4017);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4017);


    });

    //US#124751
    test("Regular user should not update existing device when required parameter - ip is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', '', 'Aut10101updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4019);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4019);


    });

    //US#124751
    test("Regular user should not update existing device when required parameter - name is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', '', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4010);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4010);

    });

    //US#124751
    test("Regular user should not update existing device when required parameter - aet is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, '', localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4014);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4014);

    });


    //US#124751
    test("Regular user should not update existing device when deviceId is empty in url @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, ' ', '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4);

    });

    //US#124751
    test("Regular user should not add a new device when deviceId is a non-existant Id @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, '12345', '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(1);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_1);

    });

    //US#124751
    test("Regular user should not update existing device when aet is already an existing value - check case insensitive for aet value @124751 @310324", async function () {
        let localUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        let localAet = localUid;
        globalAet = globalAet.toLowerCase();
        let localSerialNumber = await TestData.generateSerialNumber();
        let addresponse = await ApiHelper.addDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', localUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, localAet, localSerialNumber, '04049539104410 (CALLISTO eye)',);
        expect(addresponse.status).toBe(200);
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt2', localUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        let areEqual = new Array(), expectedJSON, iothubJSON;
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4002);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4002);

    });

    //US#124751
    test("Regular user should not update existing device when the length of aet value is greater than 16 @124751 @310324", async function () {
        //api request
        let localAet = "Aut879824365872659873284983275";
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'OPT: Ophthalmic Tomography', 1, localAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4016);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4016);
    });

    //US#124751
    // UID cannot be updated
    test("Regular user should NOT update existing device - check case insensitive for uid value @124751 @310324", async function () {

        let uid = globalUid.toLowerCase();
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', 'AutDevic10102Updt', uid, locIDfromResp, uid, 'OPT: Ophthalmic Tomography', 1, 'Aut10102', localSerialNumber, '04049471092080 (IOLMaster 700)',);
        let areEqual = new Array(), expectedJSON, iothubJSON;
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(6);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_6);

    });

    //US#124751
    test("Regular user should not update device when the required field - modality is missing @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '10111', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', '', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4013);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4013);

    });

    //US#308070 US#310324
    test("Regular user should not update device when the required field - serial number is missing @124751 @310324 @308070", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'AutDevic10102Updt', globalUid, locIDfromResp, '10102', 'US: Ultrasound', 1, globalAet, '', '040494710 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4004);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4004);

    });

    //US#308070 US#310324
    test("Regular user should not update device when the required field - device identifier is missing @308070", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'AutDevic10102Updt', globalUid, locIDfromResp, '10102', 'US: Ultrasound', 1, globalAet, localSerialNumber, ' (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4005);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4005);

    });

    //US#124751
    test("Regular user should not update device when port is not a number @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, 'p-8080', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4018);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4018);

    });

    //US#308070 US#310324
    test("Regular user should not update device when manually entered DI is more than 14 digits @308070", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, '123232311111111111111111 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4008);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4008);

    });

    //US#308070 US#310324
    test("Regular user should not update device when serial number is more than 14 digits @308070", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, '100000000000000000000000000', '123 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4009);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4009);

    });

    //US#308070 US#310324
    test("Regular user should not update device when manually entered DI is invalid @308070", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, 'aaaaaaaaaaaaaaaa (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4008);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4008);

    });

    //US#308070 US#310324
    test("Regular user should not update device when IP is invalid @308070 @380235 @381818", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        var ipadd = ['1.11...11..11...', '299.299.299.299', '5555..5555', '0000.0000.0000.0000', '111..rr..1111..', '00.0.000.0000', '0000.234.45.0000',]
        for (var k = 0; k < ipadd.length; k++) {
            console.log("port number is: " + ipadd[k])
            let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', ipadd[k], 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
            expect(response.status).toBe(400);
            expect(response.data.errorCode).toBe(4026);
            expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4026);
        }

    });

    //US#124751
    test("Regular user should not update device when port number is outside the range 0-65535 @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '-1', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4018);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4018);
        //api request
        let putResponse = await ApiHelper.updateDevice("DICOM", token, deviceId, '65536', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', globalUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(putResponse.status).toBe(400);
        expect(putResponse.data.errorCode).toBe(4001);
        expect(putResponse.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4001);

    });

    //US#124751
    test("Regular user should update device when aet contains characters other than alphabets, number, hyphen @124751 @310324", async function () {
        let localUid = await TestData.generateUIDforDevice(deviceId, sastoken);
        let localAet = localUid;
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.addDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'Aut10101Updt1', localUid, locIDfromResp, '10101Updt2', 'US: Ultrasound', 1, localAet, localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(200);

        //api request
        let postResponse = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol1.customer.internal.com', 'AutDevic10102Updt', localUid, locIDfromResp, '10102', 'US: Ultrasound', 1, localAet + "#1-2", localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(postResponse.status).toBe(200);

    });

    //US#124751
    test("Regular user should NOT update device when aet contains special characters \ @124751 @310324", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol10101upd2.customer.internal.com', 'AutDevic10102Updt', globalUid, locIDfromResp, '10102', 'US: Ultrasound', 1, 'Spl\\02', localSerialNumber, '04049471092080 (IOLMaster 700)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(0);
        expect(response.data.errorMessage).toBe(ErrorMSG.InvalidPayload);
    });

    //US#344323 
    test("API-  Validate various API error codes for regularuser to update dicom device @344323", async function ({ page }) {
        let localSerialNumber = await TestData.generateSerialNumber();
        //Creating a dicom device using l1user
        newResponse = await ApiHelper.addDevice("DICOM", l1usertoken, l1TestDevice, '1111', '198.0.0.1', 'devicename', '55555', locIDfromRespl1, '55555', 'OPT: Ophthalmic Tomography', 1, 'aetitle', localSerialNumber, '(Others)', '343456')
        expect(newResponse.status).toBe(200);
        //Updating above created device using regular user resulting into 403
        newResponse = await ApiHelper.updateDevice("DICOM", token, l1TestDevice, '1112', '198.0.0.5', 'devicename', '55555', locIDfromResp, '55555', 'OPT: Ophthalmic Tomography', 1, 'aetitle', localSerialNumber, '(Others)', '343456')
        expect(newResponse.status).toBe(403);
        //Trying to update the device using invalid token      
        var invalidToken = 'abcd'
        newResponse = await ApiHelper.updateDevice("DICOM", invalidToken, l1TestDevice, '1112', '198.0.0.5', 'devicename', '55555', locIDfromResp, '55555', 'OPT: Ophthalmic Tomography', 1, 'aetitle', localSerialNumber, '(Others)', '343456')
        expect(newResponse.status).toBe(401);
        //Deleting the created device
        newResponse = await ApiHelper.deleteDevice("DICOM", l1usertoken, l1TestDevice, '55555')
        TestData.waitFortimeOut(5000);
        expect(newResponse.status).toBe(200);
    });

    //US#353696
    test("Regular user should not update a device when required parameter - sgc is empty @353696", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', globalUid, " ", '10101', 'OPT: Ophthalmic Tomography', 1, globalAet, localSerialNumber, '04049539104410 (CALLISTO eye)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4034);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4034_1);
    });

    //US#353696
    test("Regular user should not update a device when required parameter - sgc is less than 36 character @353696", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request

        var locIDless36char = await ApiHelper.createlocname(35)
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol1.customer.internal.com', 'AutDevic1010', globalUid, locIDless36char, '10111', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049539102423 (CALLISTO eye 3.2.1 model I)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4041);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4041);
    });

    //US#353696
    test("Regular user should not update a device when required parameter - sgc is > 36 characters @353696", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();
        //api request

        var locIDgrtr36char = await ApiHelper.createlocname(37)
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol1.customer.internal.com', 'AutDevic1010', globalUid, locIDgrtr36char, '10111', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049539102423 (CALLISTO eye 3.2.1 model I)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4042);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4042);
    });

    //US#353696
    test("Regular user should not update a device when required parameter - sgc is from different customerID @353696", async function () {
        let localSerialNumber = await TestData.generateSerialNumber();

        //api request
        let response = await ApiHelper.updateDevice("DICOM", token, deviceId, '1019', 'iol1.customer.internal.com', 'AutDevic1010', globalUid, locIDfromRespl1, '10111', 'US: Ultrasound', 1, globalAet, localSerialNumber, '04049539102423 (CALLISTO eye 3.2.1 model I)',);
        expect(response.status).toBe(400);
        expect(response.data.errorCode).toBe(4047);
        expect(response.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4047);
    });
    test("Regular user should not update device when DI and Serial no are not unique @392137 ", async function () {
        //api request
        let actualData = JSON.parse("[{\"identifier\":\"04049539102423\",\"name\":\"CALLISTO eye 3.2.1 model I\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049539069092\",\"name\":\"CALLISTO eye 3.5.1 model I\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049539103512\",\"name\":\"CALLISTO eye model II\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049539069214\",\"name\":\"CALLISTO eye model III\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049471092080\",\"name\":\"IOLMaster 700\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049471092066\",\"name\":\"IOLMaster 500\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748081118\",\"name\":\"ATLAS 9000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04250668606731\",\"name\":\"VISUSCREEN 100\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04250668606724\",\"name\":\"VISUSCREEN 500\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04049471097139\",\"name\":\"VISUREF 150\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087080\",\"name\":\"CIRRUS 5000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087097\",\"name\":\"CIRRUS 500\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"04057748087141\",\"name\":\"CIRRUS 6000\",\"manufacturer\":\"Carl Zeiss Meditec AG\",\"type\":null},{\"identifier\":\"\",\"name\":\"Others\",\"manufacturer\":\"Unknown\",\"type\":null}]");
        for (let i = 0; i < actualData.length - 1; i++) {
            let localUid = await TestData.generateUIDforDevice();
            let localAet = localUid;
            let localSerialNumber = await TestData.generateSerialNumber();
            let response = await ApiHelper.addDevice("DICOM", token, deviceId, '1019', 'iol10101.customer.internal.com', 'AutDevic10101', localUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, localAet, localSerialNumber, actualData[i].identifier + '(' + actualData[i].manufacturer + ')',);
            expect(response.status).toBe(200);
            let newlocalSerialNumber = await TestData.generateSerialNumber();
            let newlocalUid = await TestData.generateUIDforDevice();
            let newlocalAet = newlocalUid;

            let response2 = await ApiHelper.addDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', newlocalUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, newlocalAet, newlocalSerialNumber, actualData[i].identifier + '(' + actualData[i].manufacturer + ')',);
            expect(response2.status).toBe(200);
            // Update the added device with similar serial no and DI which was added in the  beforeAll  method
            await ApiHelper.updateisDiSnChangedFlag(true);
            let postresponse = await ApiHelper.updateDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', newlocalUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, newlocalAet, localSerialNumber, actualData[i].identifier + '(' + actualData[i].manufacturer + ')', '', true);
            expect(postresponse.status).toBe(400);
            expect(postresponse.data.errorCode).toBe(4053);
            expect(postresponse.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4053);

            await ApiHelper.updateisDiSnChangedFlag('Missit');
            let putresponse = await ApiHelper.updateDevice("DICOM", token, deviceId, '101', 'iol10101.customer.internal.com', 'AutDevic10101', newlocalUid, locIDfromResp, '10101', 'OPT: Ophthalmic Tomography', 1, newlocalAet, localSerialNumber, actualData[i].identifier + '(' + actualData[i].manufacturer + ')', '', true);
            expect(putresponse.status).toBe(400);

        }
    });
    test.afterAll(async function () {

        await ApiHelper.deleteAll_ActiveDevice(token, deviceId)
        await ApiHelper.deleteAll_InActiveDevice(token, deviceId)
        //Delete  All Locations --->       
        await ApiHelper.deleteAll_AutomationDeviceLocations(token, customerId);
    });

});