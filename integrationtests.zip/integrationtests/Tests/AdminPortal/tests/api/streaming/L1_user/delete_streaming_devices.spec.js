const { IotHubMethods } = require('../../../../utils/iothub_methods.js');
const { TokenGenerators } = require('../../../../utils/token_generators.js');
const { default: test, expect } = require('@playwright/test');
const { TestData } = require('../../../../utils/test_data.js');
let OR = require('../../../../resources/OR.json');
let { ApiHelper } = require('../../../../helpers/api-helpers.js')
let ErrorMSG = require('../../../../resources/ErrorMSG.json');

const apimAddConnectedDevicesUrl = process.env.apimBaseURL + OR.APIUrls.addConnectedDevicesUrl;
const iothub = process.env.subscription + "-conm-" + process.env.env + "-" + process.env.locationshortcut + "-iothub-aih"
const iothubResourceUri = iothub + '.azure-devices.net/devices'
const iothubPolicyKey = process.env.iotHubPolicyKey
const iothubPolicy = 'iothubowner'
let sastoken, deviceId, token, conn, locIDfromResp, customerDetailsId, customerId, customer, customerDetailsRecordSet;
let testDevice = process.env.serviceUserHypervDeviceId
test.describe("Delete Streaming and BOTH Connected Devices API for L1 user", function () {
    test.beforeAll(async function () {
        sastoken = await TokenGenerators.generateSasToken(iothubResourceUri, iothubPolicyKey, iothubPolicy, 30)

        conn = await TestData.sqlDBConnection();
        let devicesRecordSet = await TestData.executeSqlQuery(conn, "select top(1) * from [dbo].[Device] where iotdeviceId = '" + testDevice + "' for json auto")
        let deviceRecord = JSON.parse(devicesRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        deviceId = deviceRecord[0].iotDeviceId;
        customerDetailsId = deviceRecord[0].customerDetailsId;
        conn = await TestData.sqlDBConnection();
        customerDetailsRecordSet = await TestData.executeSqlQuery(conn, "select * from [dbo].[CustomerDetails] where customerdetailsId=" + customerDetailsId + " for json auto")
        var customerDetailsRecord = JSON.parse(customerDetailsRecordSet['recordset'][0]['JSON_F52E2B61-18A1-11d1-B105-00805F49916B']);
        customerId = customerDetailsRecord[0].customerId;
        customer = customerDetailsRecord[0].customerName;
        console.log("customerId: " + customerId)
        console.log("deviceId: " + deviceId)
        token = await TokenGenerators.generateAuthToken("l1serviceuser");

    })


    //US#412586
    test("API L1 user should be able to delete the Streaming device and then device should be deleted from module twin @412586", async function () {
        // create location-->
        var locName = "AutoLoc-L1Del-StreamingDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;

        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("STREAMING", token, deviceId, null, "iol1.customer.internal.com", "AutStreaming-001", null, locIDfromResp, null, "OPT: Ophthalmic Tomography", 1, null, localSerialNumber, "04049539102423(CALLISTO eye 3.2.1 model I)",)

        expect(response.status).toBe(200);
        var deviceUid = await ApiHelper.getUidofConnectedDevice(token, deviceId, "AutStreaming-001", localSerialNumber);
        let deleteResponse = await ApiHelper.deleteDevice("STREAMING", token, deviceId, deviceUid)
        expect(deleteResponse.status).toBe(200);
        await TestData.waitFortimeOut(15000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(deviceUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);

    })

    //US#412586
    test("With L1 user_API Should throw error while deleting Streaming Device when deviceID is missing or invalid / validating different error codes @412586", async function () {
        // create location-->
        var locName = "AutoLoc-L1Del-StreamingDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;

        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("STREAMING", token, deviceId, null, "iol1.customer.internal.com", "AutStreaming-002", null, locIDfromResp, null, "OPT: Ophthalmic Tomography", 1, null, localSerialNumber, "04049539102423(CALLISTO eye 3.2.1 model I)",)

        expect(response.status).toBe(200);
        var deviceUid = await ApiHelper.getUidofConnectedDevice(token, deviceId, "AutStreaming-002", localSerialNumber);

        let deleteinvalidResponse = await ApiHelper.deleteDevice("STREAMING", token, "invalid", deviceUid)
        expect(deleteinvalidResponse.status).toBe(400);
        expect(deleteinvalidResponse.data.errorMessage).toBe(ErrorMSG.ErrorMsg_1);
        expect(deleteinvalidResponse.data.errorCode).toBe(1);

        let deleteResponse = await ApiHelper.deleteDevice("STREAMING", token, " ", deviceUid)
        expect(deleteResponse.status).toBe(400);

        let deleteLatestResponse = await ApiHelper.deleteDevice("STREAMING", token, deviceId, deviceUid)
        expect(deleteLatestResponse.status).toBe(200);

        await TestData.waitFortimeOut(5000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(deviceUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);
    })

    //US#412586
    test("With L1 user_API Should throw proper error for negative cases in case of delete api @412586", async function () {
        // create location-->
        var locName = "AutoLoc-L1Del-StreamingDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;

        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("STREAMING", token, deviceId, null, "iol1.customer.internal.com", "AutStreaming-002", null, locIDfromResp, null, "OPT: Ophthalmic Tomography", 1, null, localSerialNumber, "04049539102423(CALLISTO eye 3.2.1 model I)",)

        expect(response.status).toBe(200);
        var deviceUid = await ApiHelper.getUidofConnectedDevice(token, deviceId, "AutStreaming-002", localSerialNumber);

        //trying to delete a streaming device by passing DICOM as service type
        let deleteinvalidResponse = await ApiHelper.deleteDevice("DICOM", token, deviceId, deviceUid)
        expect(deleteinvalidResponse.status).toBe(400);
        expect(deleteinvalidResponse.data.errorMessage).toBe(ErrorMSG.ErrorMsg_4057);
        expect(deleteinvalidResponse.data.errorCode).toBe(4057);

        //trying to delete a streaming device by passing BOTH as service type
        let deleteResponse = await ApiHelper.deleteDevice("BOTH", token, deviceId, deviceUid)
        expect(deleteResponse.status).toBe(400);

        //trying to delete a streaming device by passing invalid uid
        let deleteLatestResponse = await ApiHelper.deleteDevice("STREAMING", token, deviceId, "deviceUid")
        expect(deleteLatestResponse.status).toBe(400);

    })


    //US#412586
    test("API L1 user should be not able to delete the Both device by passing DICOM/Streaming and should not be deleted from both module twin @412586", async function () {
        // create location-->
        var locName = "AutoLoc-L1Del-StreamingDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;
        let localUid = await TestData.generateUIDforDevice(deviceId, sastoken);

        //creating a both device
        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("BOTH", token, deviceId, "9090", "iol1.customer.internal.com", "AutStreaming-004", localUid, locIDfromResp, localUid, "OPT: Ophthalmic Tomography", 1, localUid, localSerialNumber, "04049539102423(CALLISTO eye 3.2.1 model I)",)
        expect(response.status).toBe(200);

        //trying to delete a both device using Streaming type
        let deleteResponse = await ApiHelper.deleteDevice("STREAMING", token, deviceId, localUid)
        expect(deleteResponse.status).toBe(400);

        //trying to delete both device using DICOM type
        deleteResponse = await ApiHelper.deleteDevice("DICOM", token, deviceId, localUid)
        expect(deleteResponse.status).toBe(400);
        await TestData.waitFortimeOut(25000);

         //validating dicom forwarder module that device is not deleted
         let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
         let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
         if (iotHubConnectedDevices2) {
             iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(localUid);
         }
         expect(iotHubConnectedDevices2).toBe(true);

        //validating streaming module twin that device is not deleted
        iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(localUid);
        }
        expect(iotHubConnectedDevices2).toBe(true);      

    })

    //US#412586
    test("With L1 user_API Should be able to delete a both device @412586", async function () {
        // create location-->
        var locName = "AutoLoc-L1Del-StreamingDiv" + await ApiHelper.createlocname(4)
        var locDesc = "This is the location: " + locName
        var status = "active"
        var postresponse = await ApiHelper.postlocationList(token, customerId, locName, locDesc, status)
        expect(postresponse.status).toBe(200);
        locIDfromResp = postresponse.data.result.id;
        let localUid = await TestData.generateUIDforDevice(deviceId, sastoken);

        let localSerialNumber = await TestData.generateSerialNumber();
        let response = await ApiHelper.addDevice("BOTH", token, deviceId, "9090", "iol1.customer.internal.com", "AutStreaming-005", localUid, locIDfromResp, localUid, "OPT: Ophthalmic Tomography", 1, localUid, localSerialNumber, "04049539102423(CALLISTO eye 3.2.1 model I)",)

        expect(response.status).toBe(200);

        let deleteinvalidResponse = await ApiHelper.deleteDevice("BOTH", token, deviceId, localUid)
        expect(deleteinvalidResponse.status).toBe(200);

        await TestData.waitFortimeOut(5000);

        let iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "streamingmodule", sastoken);
        let iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(localUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);

        iothubResponse = await IotHubMethods.getModuleTwin(iothub, deviceId, "dicomforwardermodule", sastoken);
        iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices ? true : false;
        if (iotHubConnectedDevices2) {
            iotHubConnectedDevices2 = iothubResponse.data[0].properties.desired.connectedDevices.hasOwnProperty(localUid);
        }
        expect(iotHubConnectedDevices2).toBe(false);
    })

    test.afterEach(async function () {
        await ApiHelper.deleteAll_ActiveDevice(token, deviceId)
        await ApiHelper.deleteAll_InActiveDevice(token, deviceId)
        await ApiHelper.deleteAll_AutomationDeviceLocations(token, customerId);

    });

})
